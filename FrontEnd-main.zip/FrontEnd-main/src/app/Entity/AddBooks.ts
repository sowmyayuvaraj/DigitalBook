export default class AddBooks{
    public bid:number=0;
   public  logo:string = "";
    public title:string = "";
    public category:string="";
   public publisher_name:string="";
   public price:number=0;
    public published_date:Date=new Date();
    public chapters:string="";
   public active:string="";
    public author_name:string="";
    public aid:number=0;
    


}

