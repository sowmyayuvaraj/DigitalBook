export default class AddBooks{
    public bid:number=0;
    public  logo:string = "";
    public title:string = "";
    public category:string="";
    public publisherName:string="";
    public price:number=0;
    public publishedDate:Date=new Date();
    public chapters:string="";
    public active:string="";
    public authorName:string="";
   
    

}
