export default class Author{


public aid:number=0;
public  authorName:string = "";

}