export default class Readers{
    rId:number=0;
    name:string = '';
    email:string = ''
    bId:number=0;  
    payId:number=0;  
}