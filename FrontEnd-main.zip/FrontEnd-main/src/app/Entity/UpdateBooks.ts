export default class UpdateBooks{
    public bid:number=0;
    public  logo:string = "";
    public title:string = "";
    public category:string="";
    public publisherName:string="";
    public price:number=0;
    public publishedDate:Date=new Date();
    public chapters:number=0;
    public active:string="";
    public authorName:string="";

   
    

}
