import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { NavbarComponent } from './Components/navbar/navbar.component';
import { AboutComponent } from './Components/about/about.component';

import { ReaderUserFromComponent } from './Components/reader/reader.component';
import { AuthorOnlyComponent } from './Components/author-only/author-only.component';
import { AddBookComponent } from './Components/add-book/add-book.component';
import { AuthorListComponent } from './Components/author-list/author-list.component';
import { FindPurchasedBooksComponent } from './Components/find-purchased-books/find-purchased-books.component';
import { BookListComponent } from './Components/book-list/book-list.component';
import { BookContentComponent } from './Components/book-content/book-content.component';
import { BooksByPaymentComponent } from './Components/books-by-payment/books-by-payment.component';
import { RefundComponent } from './Components/refund/refund.component';
import { SearchBooksComponent } from './Components/search-books/search-books.component';
import { UpdateBookComponent } from './Components/update-book/update-book.component';
import { UpdateTestComponent } from './Components/update-test/update-test.component';


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    AboutComponent,
   
    ReaderUserFromComponent,
    AuthorOnlyComponent,
    AddBookComponent,
    AuthorListComponent,
    FindPurchasedBooksComponent,
    BookListComponent,
    BookContentComponent,
    BooksByPaymentComponent,
    RefundComponent,
    SearchBooksComponent,
    UpdateBookComponent,
    UpdateTestComponent,

  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
